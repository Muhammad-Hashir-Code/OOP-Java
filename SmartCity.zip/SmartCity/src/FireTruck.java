public class FireTruck extends Transport_Units{

    FireTruck(String unitID,String type,boolean isAvailable,int dispatchCount)
        {
            this.unitId=unitID;
            this.unitType=type;
            this.isAvailable=isAvailable;
            this.dispatchCount=dispatchCount;
        }

        protected void repondToAction()
        {
            System.out.println("Police Van has been reponded");
            super.respondToAction();
        }
    }




