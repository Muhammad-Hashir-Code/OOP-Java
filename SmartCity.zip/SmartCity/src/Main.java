public class Main {
    public static void main(String[] args) {
        // Create a Registration object
        Registration registration = new Registration("Downtown", 5, "2025-04-06 12:00:00");

        // Create an IncidentReport based on the registration
        IncidentReport report = new IncidentReport(registration);

        // Upcasting: Transport_Units reference holding child class objects
        Transport_Units ambulance = new Ambulance("AMB001", "Ambulance", true, 3);
        Transport_Units policeVan = new PoliceVan("POL001", "Police Van", true, 5);
        Transport_Units fireTruck = new FireTruck("FIR001", "Fire Truck", true, 2);

        // Call the subclass methods (due to dynamic dispatch, the overridden methods will be called)
        ((Ambulance) ambulance).repondToAction();     // Typo kept
        ((PoliceVan) policeVan).repondToAction();
        ((FireTruck) fireTruck).repondToAction();

        // Optionally store all transport units in an array
        Transport_Units[] units = { ambulance, policeVan, fireTruck };

        // Loop through and call respondToAction() using parent reference
        for (Transport_Units unit : units) {
            unit.respondToAction(); // This calls the parent method, not overridden one due to no polymorphism here
        }
    }
}
