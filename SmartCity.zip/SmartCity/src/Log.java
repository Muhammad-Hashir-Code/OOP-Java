import java.util.ArrayList;
public class Log {
    //Registration registration;
    ArrayList<Registration> registrations=new ArrayList<>();
}
