public class PoliceVan extends Transport_Units{
    PoliceVan(String unitID,String type,boolean isAvailable,int dispatchCount)
    {
      this.unitId=unitID;
      this.unitType=type;
      this.isAvailable=isAvailable;
      this.dispatchCount=dispatchCount;
    }

    protected void repondToAction()
    {
        System.out.println("Police Van has been reponded");
        super.respondToAction();
    }
}
