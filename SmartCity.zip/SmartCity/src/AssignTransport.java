public class AssignTransport {
    AssignTransport(Transport_Units t)
    {
        System.out.println("Assign Transport is:"+t.toString());
    }

}
