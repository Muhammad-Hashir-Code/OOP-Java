public class Registration {
    protected String location;
    protected int severity;
    protected String timestamp;
    Log l=new Log();
    Registration(String location, int severity, String timestamp) {
        this.location = location;
        this.severity = severity;
        this.timestamp = timestamp;
        l.registrations.add(this);
    }
    @Override
    public String toString() {
        return "Location: " + location + ", Severity: " + severity + ", Time: " + timestamp;
    }


}
