public class Transport_Units {
    protected String unitId;
    protected String unitType;
    protected boolean isAvailable;
    protected int dispatchCount;

//Objects Used
    Registration registration;
    Transport_Units t;

    Transport_Units() {

    }
    @Override
    public String toString() {
        return "Unit ID: " + unitId + ", Type: " + unitType + ", Available: " + isAvailable + ", Dispatches: " + dispatchCount;
    }
    protected static int totalDispatched = 0;

    protected void respondToAction() {
        totalDispatched++;
        AssignTransport assignTransport = new AssignTransport(this);
    }

    public static void printTotalDispatched() {
        System.out.println("Total Units Dispatched: " + totalDispatched);
    }

}
