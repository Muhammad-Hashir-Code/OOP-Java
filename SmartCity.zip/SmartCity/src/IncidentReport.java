public class IncidentReport {

    IncidentReport(Registration registration)
    {
        System.out.println("The details of the incident report are:"+registration.toString());
    }
}
